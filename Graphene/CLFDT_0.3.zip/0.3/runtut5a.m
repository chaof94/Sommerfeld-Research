%% FDTD-TRTS
% FDTD implementation of time-resolved THz-spectroscopy (TRTS)
% Developed by Casper Larsen, 2010, DTU, Denmark
% Please cite: "C. Larsen, D. Cooke, P. U. Jepsen, Finite-Difference
% Time-Domain Analysis of Time-resolved THz Spectroscopy Experiments, JOSA B 2011".
% See user manual for explanations and usage

function dac = runtut5a(dac)
    [x,resnorm,residual,exitflag,output,lambda,J] = lsqnonlin(@cl1Dpumpfunopti,dac.x0,dac.xlb,[],dac.options,dac);    % Invoke optimizer
    dac.x = x;
    dac.residual = residual;
    dac.ci = nlparci(dac.x,dac.residual,'jacobian',J);
    if exitflag < 1
        disp('Exceeded options.MaxFuncEvals')
    end
end

function F = cl1Dpumpfunopti(x,dac)
    o = runtut5b(x);
    cla;
    plot(dac.t,dac.DT,o.t,o.detN*dac.DT0)
    drawnow
    DTint = interp1(o.t,o.detN,dac.t,'linear','extrap');
    F = [(dac.DT(dac.ntmin:end) - dac.DT0*DTint(dac.ntmin:end))]';
end