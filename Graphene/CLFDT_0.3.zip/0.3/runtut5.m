%% FDTD-TRTS
% FDTD implementation of time-resolved THz-spectroscopy (TRTS)
% Developed by Casper Larsen, 2010, DTU, Denmark
% Please cite: "C. Larsen, D. Cooke, P. U. Jepsen, Finite-Difference
% Time-Domain Analysis of Time-resolved THz Spectroscopy Experiments, JOSA B 2011".
% See user manual for explanations and usage

figure,
tmpref = importdata('1DpumpGaAs800.1pm');
t = tmpref(:,1);
DT = tmpref(:,4);
[a b] = max(DT);
plot(t,DT) 
hold all

xlabel('Pump delay, ps')
ylabel('Normalized differential transmission, \Delta T')
xlim([0,500])
ylim([-0.1,0.5])
%%
tmin = 20; % minimum time, ps (only late times are fitted)
x0 = [6100 6e5 3.37]; % bulk recomb: rb, ps; surf. recomb: rs, cm/s ;  diffusion coeff: D, cm^2 s^-1 
dac.x0 = [1/x0(1) x0(2)*1e-8 x0(3)*1e-4]; % bulk recomb: rb, ps^-1; surf. recomb: rs, �m/ps ;  diffusion coeff: D, �m^2 ps^-1
% dac.x0 = [1/6100 6e5*1e-8 3.37*1e-4]; % bulk recomb: rb, ps^-1; surf. recomb: rs, �m/ps ;  diffusion coeff: D, �m^2 ps^-1
dac.t = t;
dac.DT = DT;
dac.DT0 = a;
dac.ntmin = find(dac.t >= tmin,1,'first');
dac.xlb = zeros(size(dac.x0));
dac.options = optimset('Display','iter','MaxFunEvals',20,'TolFun',1e-15,'TolX',1e-15);

dac = runtut5a(dac);

ci1 = 1/(dac.x(1) - max(dac.ci(1,:)-dac.x(1)))- 1/(dac.x(1));
ci2 = max(dac.ci(2,:)-dac.x(2));
ci3 = max(dac.ci(3,:)-dac.x(3));
disp('The fit result:')
disp(['Bulk recombination rate:        ' num2str(1/dac.x(1)),' +- ' num2str(ci1) ' ps'])
disp(['Surface recombination velocity: ' num2str(dac.x(2)*1e8,4),' +- ' num2str(ci2*1e8,4) ' cm/s'])
disp(['Diffusion coefficient:          ' num2str(dac.x(3)*1e4,4),' +- ' num2str(ci3*1e4,4) ' cm^2/s'])
