%% FDTD-TRTS
% FDTD implementation of time-resolved THz-spectroscopy (TRTS)
% Developed by Casper Larsen, 2010, DTU, Denmark
% Please cite: "C. Larsen, D. Cooke, P. U. Jepsen, Finite-Difference
% Time-Domain Analysis of Time-resolved THz Spectroscopy Experiments, JOSA B 2011".
% See user manual for explanations and usage

% ######################
% Numerical stepping parameters
% ######################
c.xpmtype = 3;          % experiment type: 1 (1Dprobe), 2 (1Dpump), 3 (2Dpump-probe)
c.prop = 1;             % evolve system, 0 or 1
c.parallel = 0;         % Enable parallel processing of 2Dpumpprobe (using available CPU cores)
c.diffusion = 1;        % activation of diffusion and surface recombination of carriers, 0 or 1
c.xpmid = 'tut3';       % name of experiment (used for saving)
c.save = 1;             % save input and output data, 0 or 1
c.Nh = 2^9;             % spatial domain resolution
c.Nt = 2^14;            % time steps
c.Nsav = 2^10;          % number of time steps stored
c.Q = 1;                % FDTD quality factor

% ######################
% Probe pulse
% ######################
c.useEref = 0;          % use the eref in file 'Eref.dat', 0 or 1
c.EA = 100;             % amplitude of pulse, ab.unit
c.t0 = 0.20;               % time of start of pulse, ps
    % the following is only active for useEref = 0
c.ome0 = 3 *2*pi;       % center frequency, THz
c.pulseW = 1.5/c.ome0;  % envelope of pulse in time, ps
c.chirp = 0;            % chirp of probe pulse, ps^-1


% ######################
% Pump pulse
% ######################
c.usepump = 1;          % use the pump: 0 or 1
    % tp is the time from pump to probe: negative is after probe t0:
c.tp = 0.1;            % pump delay [1Dprobe] or first pump delay [1Dpump], ps                        
c.ng = 4;               % group index of refraction of pump
c.pumpW = 0.1;          % pump time-width, ps
c.F = 8;                % pump fluence, �J/cm^2/pulse
c.lamp = 0.8;           % pump wavelength, �m
c.abp = 0.7;            % absorption depth of pump, �m
c.Rpump = 0.33;         % reflectance of pump at pump wavelength
    % specific for 2D pumpprobe:
c.mintp = -0.5;           % first pump delay, ps (remember cost of reconstruction)
c.maxtp = 1;            % last pump delay, ps
c.Ntp = 30;             % number of pump delays
    % specific for 1D pump:
c.tpfac1D = 200;        % increase time step size by this factor
    % when usepump = 0:
c.pumpexp = 0;          % exponential density at start (for long times), 0 or 1
c.densityconst = 0;     % homogene density at start, 0 or 1

% ######################
% Medium
% ######################
c.d = 10;               % thickness of simulated region, �m
c.eps00 = 13;           % background relative permittivity
c.epsin = 1;            % relative permittivity at input side
c.epsout = c.eps00;     % relative permittivity at output side

p = 1;                  % excited medium 1
m(p).g = 1.3*2*pi;      % electron scattering rate, ps^-1
m(p).rb = 0;            % bulk recombination rate, ps^-1
m(p).w0 = 0 *2*pi;      % resonance frequency, THz
m(p).meff = 0.067;      % effective electron mass, meff*me = me*
m(p).rs = 1e6*1e-8;     % surface recombination velocity, �m/ps  
m(p).D = 21*  1e-4;     % diffusion coefficient, �m^2/ps
m(p).y = 1; %0;         % yield of pump
m(p).rpp = [0 5 0]; 	% rate from other poles [p1 p2 p3], ps^-1

% p = 2;                  % excited medium 2
% m(p).g = 3*2*pi;        % electron scattering rate, ps^-1
% m(p).rb = 0;            % bulk recombination rate, ps^-1
% m(p).w0 = 0 *2*pi;      % resonance frequency, THz
% m(p).meff = 0.067;      % effective electron mass, meff*me = me*
% m(p).rs = 1e6*1e-8;     % surface recombination velocity, �m/ps  
% m(p).D = 21*  1e-4;     % diffusion coefficient, �m^2/ps
% m(p).y = 1;             % yield of pump
% m(p).rpp = [0 0 0];     % rate from other poles [p1 p2 p3], ps^-1

% ######################
% PML (boundaries)
% ######################
c.Amax = 0.18574656389; % absorption coefficient of PML
c.Am = 1.4293377164138; % PML m parameter
c.Ah = 20;              % width of PML
c.sph = 3;              % size of space between elements in the domain

% ######################
% Plot parameters
% ######################
ps.numpar = 1;          % display numerical and material parameters message, 0 or 1
ps.real = 2^9;          % "live" plotting every # iterations
ps.plot = 1;            % analysis of results by various plots, 1-5
ps.fxlim = [0.3,6.5];   % plot frequency limits (determined by bandwidth of probe)
ps.Nfft = 2^12;         % resolution of FFT when plotting

% ######################
% Function calls
% ######################
[o] = clFDTmain(c,m,ps);% call main function 

% if requirements for the use of the lite version is meet it is possible to use:
% [o] = clFDTmainlite(c,m,ps);% call main function 



