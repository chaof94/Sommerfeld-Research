function [o] = clFDTmainlite(c,m,ps) 
%%
% FDTD implementation of time-resolved THz-spectroscopy (TRTS)
% Developed by Casper Larsen, 2010, DTU, Denmark
% Please cite: "C. Larsen, D. Cooke, P. U. Jepsen, Finite-Difference
% Time-Domain Analysis of Time-resolved THz Spectroscopy Experiments, JOSA B 2011".

    tic % Record time
    switch c.xpmtype % execute subfunctions
        case 1 % 1D probe experiment
            o = clFDTcorelite(c,m,ps);   
        case 2 % 1D pump experiment
            o = clFDTcorelite(c,m,ps); 
        case 3 % 2D pump probe experiment
            [o] = FDT2Dpumpprobelite(c,m,ps);
    end
    o.toc = toc; 
    toc % Display time of calculation
    if c.save == 1
        t = clock;
        idclock = sprintf('-%0.4d-%0.2d-%0.2d-%0.2d-%0.2d', t(1), t(2), t(3), t(4), t(5));
        save([c.xpmid idclock '.mat'],'c','m','ps','o')
    end
    
    if ps.plot ~= 0 && c.prop == 1
        clFDTplot(c,m,ps,o); % plot
    end
end

%% Subfunctions
function [o] = FDT2Dpumpprobelite(c,m,ps)
    ps.real = 0; ps.numpar = 0;
    if c.parallel == 1
        matlabpool; % initiate parallel processing
    end
    vtp = linspace(c.mintp,c.maxtp,c.Ntp);
    detT2D = zeros(c.Nsav,c.Ntp);
    detR2D = zeros(c.Nsav,c.Ntp);
    parfor j = 1:c.Ntp % propagate 2D
        [to] = clFDTcorelite(c,m,ps,vtp(j));
        detT2D(:,j) = to.detT;
        detR2D(:,j) = to.detR;
    end
    [o] = clFDTcorelite(c,m,ps,min(vtp),0);
    o.detT2D = detT2D; % 2d transmission
    o.detR2D = detR2D; % 2d reflection
    o.vtp = vtp;
    if c.parallel == 1;    
        matlabpool close % close parallel processing
    end
end

function [o] = clFDTcorelite(c,m,ps,tp,usepump)
if nargin > 3                       % chose pump time
    c.tp = tp;
end
if nargin > 4                       % enable pump
    c.usepump = usepump;
end
o = struct;                         % output structure

% ######################
% Constants
% ######################
T = 300;                            % temperature in K
c0 = 299792458*1e-6;                % light speed, �m/ps
eps0 = 8.065618045839289;           % vacuum permittivity, �A^2 ps^4/me �m^3 (8.8541878176e-12 * 9.10938215e-31 * (1e6)^2* (1e12)^4 * (1e-6)^3)
e0 = 0.1602176487;                  % elementary charge, �A ps (1.602176487e-19*1e12*1e6)
me = 1;                             % electron mass, 1 me (9.10938215e-31 kg)
Vp = 1.097769292728596;             % voltage, me �m^2 / ps^3 �A,  [V] = kg m^2/s^3 A (1/9.10938215e-31 *1e6^2* 1e12^-3* 1e-6)
kb = 1.515635503336524e-5;          % boltzmann constant, me �m^2/ps^2 K, [kb]_SI = kg m^2 / s^2 K (1.3806503e-23 * 1/9.10938215e-31* 1e6^2* 1e-12^2)
hcon = 6.62606896e-022;             % planck constant in J ps (6.62606896e-34*1e12)
h = c.d/(c.Nh-2*c.Ah-6*c.sph);      % spatial step size, �m
dt = c.Q*h/c0;                      % time step size, ps
if c.xpmtype == 2 % 1D pump
    dt = dt*c.tpfac1D;      % increase time step by tpfac1D
end
tmax = dt*c.Nt;                     % propagation time, ps
zmax = h*c.Nh;                      % domain length, �m

% ######################
% Setup vectors and stuff 
% ######################
A = zeros(c.Nh,1);                  % PML vector
A(1:c.Ah) = c.Amax*(1- ((1:c.Ah)-1)./c.Ah).^c.Am;       % left part PML E
A(c.Nh-c.Ah+1:c.Nh) = c.Amax*((1:c.Ah)./c.Ah).^c.Am;    % right part PML E
App = 1+A;                          % puls PML E vector
Amm = 1-A;                          % minus PML E vector
AH = (A(2:c.Nh) + A(1:c.Nh-1))/2;   % PML H i+1/2
AH = [AH; AH(end)];           	    % PML H i+1/2 complete vector
AHpp = 1+AH;                        % puls PML H vector
AHmm = 1-AH;                        % minus PML H vector

o.t = linspace(0,tmax,c.Nsav);      % time vector of E, ps
o.z = linspace(0,zmax,c.Nh);        % position of E, �m
E = zeros(c.Nh,1);                  % electric field, Vp/�m
H = zeros(c.Nh,1);                  % magnetic field, 
o.detR = zeros(c.Nsav,1);           % reflection detector
o.detT = zeros(c.Nsav,1);           % transmission detector
o.detJ = zeros(c.Nsav,1);           % polarization detector
o.detx = zeros(c.Nsav,1);          % displacement detector
o.detN = zeros(c.Nsav,1);          % density detector

Mst = c.Ah+4*c.sph+1;               % start of medium
Mend = c.Nh-c.Ah-2*c.sph;           % end of medium
Ms = Mend-Mst+1;                    % size of medium
Msource = c.Ah+2*c.sph+1;           % position of source
Nskip = c.Nt/c.Nsav;                % store very Nskip time-steps

ep = c.epsin*ones(c.Nh,1);          % permittivity vector
ep(Mst:Mend) = c.eps00;             % setup permittivity vector from eps00
ep(Mend+1:c.Nh) = c.epsout;         % setup permittivity vector from epsout
eee = e0./(ep*eps0);                % response parameter

tl = linspace(0,tmax,c.Nt);         % long time vector, ps
SE = c.EA.*sin( c.ome0*(tl-c.t0).*(1+c.chirp.*(tl-c.t0)) ).*exp(-(tl-c.t0).^2/(2*c.pulseW^2)); % long input vector
o.detI = c.EA.*sin( c.ome0*(o.t-c.t0).*(1+c.chirp.*(o.t-c.t0)) ).*exp(-(o.t-c.t0).^2/(2*c.pulseW^2)); % input vector at stored times

% ######################
% Dynamic material and pump parameters
% ######################
o.Nmax = c.F * 1e-6*(1e-4)^2 *c.lamp* (1-c.Rpump) /(hcon*c0*c.abp); % maximum carrier density in �m^-3
Iamp = o.Nmax/(sqrt(pi)*c.pumpW*c.abp);                 % normalization factor of I
z0 = o.z(Mst);                                          % start position of medium
o.x = transpose(o.z(Mst:Mend)-z0);                      % reduced position vector
pumpWz = c0*c.pumpW/c.ng;                               % pump width in space
pumpprop = 10* max([c.abp pumpWz]);                     % length of propagation of pump
nattem = round(((-10*pumpWz-z0)*c.ng/c0 - c.tp + c.t0)/dt); % determines first time step with pump
natten = round(((pumpprop-z0)*c.ng/c0 - c.tp + c.t0)/dt);   % determines last time step with pump

Ik1 = o.x-c0/c.ng*(c.tp - c.t0);        % Pump parameter 1
Ik2 = c0/c.ng*dt;                       % Pump parameter 2
Ik3 = 1/pumpWz.^2;                      % Pump parameter 3
I0 = c.usepump.*Iamp.*exp(-o.x/c.abp);  % Setup pump vector
I = zeros(Ms,1);

% ######################
% Initiate material response 
% ######################
m.N = m.y*o.Nmax*ones(Ms,1)*exp(-1);    % set density to maximum temporarily
m.D = m.D.*ones(Ms,1);                  % diffusion constant, �m^2/ps
m.g = m.g.*ones(Ms,1);                  % electron scattering rate, ps^-1
m.al = (4-2*m.w0^2*dt^2)./(2 + m.g*dt); % alpha parameter
m.be = (m.g*dt-2)./(m.g.*dt+2);         % beta parameter
m.mue = e0/(m.g(1).*m.meff);            % electron mobility (not used)
m.th0 = 2.*e0.*dt.^2./ m.meff ;         % theta parameter  
m.th = m.th0./(2 + m.g.*dt);            % theta parameter
m.x0 = zeros(Ms,1);                     % temporary displacement vector
m.x = zeros(Ms,1);                      % current displacement vector
m.N0 = zeros(Ms,1);                     % setup old density vector

% ######################
% Checks
% ######################
if ps.numpar == 1
    disp(['Nh: ' num2str(c.Nh) ', h: ' num2str(h*1e3) 'nm, Zmax: ' num2str(zmax) '�m, d: ' num2str(c.d) ...
            '�m | Nt: ' num2str(c.Nt) ', dt: ' num2str(dt*1e3) 'fs, Tmax: ' num2str(tmax) 'ps, df: ' num2str(1/tmax) 'THz']);
    disp(['F: ' num2str(m.y*c.F) '�J/cm^2, Nmax: ' num2str(m.y*o.Nmax*1e12,'%.3g') 'cm^-3, mu_e: '...
        num2str(m.mue(1)*Vp*1e4,'%.4g') 'cm^2/Vs,  D: ' ...
        num2str(m.D(1)*1e4,'%.3g') 'cm^2/s, s: ' num2str(m.rs*1e8,'%.3g') 'cm/s, gamma: ' num2str(m.g(1),'%.3g')...
        'aTHz , w_p: ' num2str(sqrt(m.y*o.Nmax*e0^2/eps0/m.meff),'%.3g') 'aTHz']);
end
if (max(m.rs)*dt/(2*h)) >= 1 
    disp('Surface recombination stability factor larger than 1')
    return
end
if (2*dt*max(m.D)/h^2) >= 1 
    disp('Diffusion stability factor larger than 1')
    return
end
if Nskip < 1; c.Nsav = c.Nt; disp('Nsav > Nt'); end
if mod(Nskip,1) > 0, disp('Nt must be dividable with Nsav'), end
if c.xpmtype == 2 % 1D pump
    if nattem < 1
        disp(['c.tp must be smaller: ~' num2str(nattem*dt+c.tp) 'ps'])
        return
    end
    if c.diffusion == 0
        disp('In 1D pump experiments diffusion is needed!')
        return
    end
    if ps.numpar == 1
        disp(['Maximum dt: ~' num2str(min([2*h/max(m(1).rs) h^2/(2*max(m(1).D))])*1e3) ...
         'ps, pump propagates in: ' num2str(natten-nattem) ' steps'])
    end
end

% ######################
% Propagate system
% ######################
if ps.real > 0 && c.xpmtype ~= 3
    figure('Color',[1 1 1],'position',[100 100 800 600],'DefaultAxesColorOrder',...
       [0 0 0; 1 0.05 0.05; 0.05 0.05 0.9; 0.05 0.8 0.05; 0.4 0.4 0.4]);
    ax1 = subplot(2,2,1,'nextplot','replacechildren');
    xlabel('Position, �m')
    ylabel('Electric field and \epsilon(z)/ \epsilon_\infty')
    ylim([-1,1])
    xlim([0 max(o.z)])
    ax2 = subplot(2,2,2,'nextplot','replacechildren');
    xlabel('Time, ps')
    ylabel('Trans. and Reflec.')
    ylim([-1,1])
    xlim([0 max(o.t)])
    ax3 = subplot(2,2,3,'nextplot','replacechildren');
    xlabel('Position, �m')
    ylabel('Carrier Density, 10^{17} cm^{-3}')
%     ylim([0 1.1])
    xlim([0 max(o.x)])
    ax4 = subplot(2,2,4,'nextplot','replacechildren');
    xlabel('Time, ps')
    ylabel('Near Surface Carrier Density, 10^{17} cm^{-3}')
%     ylim([0 1.1])
    xlim([0 max(o.t)])
end

% ######################
% Setup densities
% ######################
m.N = zeros(Ms,1);              % density
if c.pumpexp == 1               % exponential decaying density in space
    m.N = m.y*o.Nmax*exp(-o.x/c.abp);
    if c.usepump == 1
        disp('conflict pumpexp and usepump')
    end
end
if c.densityconst == 1             % uniform density
    m.N = m.y*o.Nmax*ones(Ms,1);
    if c.usepump == 1
        disp('conflict densityconst and usepump')
    end
end

% ######################
% Simulate 1D pump experiment
% ######################
if c.xpmtype == 2
    for n = 1:c.Nt
        if n < natten
            I = I0.*exp( -(Ik1 -Ik2*n).^2.*Ik3); % pump at time n
        elseif n == natten 
            I = zeros(Ms,1);    % pump is gone
        end
        m.N0 =  m.N;          	% store old density
        m.N(2:Ms-1) = dt.*m.y.*I(2:Ms-1) + m.N(2:Ms-1).*(1 - dt.*m.rb - 2.*dt./(h.^2).*m.D(2:Ms-1))... 
            + dt.*m.D(2:Ms-1)./(h.^2) .* ( m.N(3:Ms) + m.N(1:Ms-2) ); 
        m.N(Ms) = dt.*m.y.*I(Ms) + m.N0(Ms).*(1 - dt.*m.rb - dt./(h.^2).*m.D(Ms))...
            + dt.*m.D(Ms)./(h.^2) .* ( m.N0(Ms-1) ); 
        m.N(1) = dt.*m.y.*I(1) + m.N0(1).*(1-dt*m.rs/h - dt.*m.rb - dt./(h.^2).*m.D(1))...
            + dt.*m.D(1)./(h.^2) .* m.N0(2);
        if ~mod(n,Nskip)
            o.detx(n/Nskip) = m.N(3);    % surface density 
            o.detN(n/Nskip) = sum(m.N);  % spatial integral of density detector
        end
        if ~mod(n,ps.real)
            cla(ax3),cla(ax4)
            line(o.x,m.N*1e-5,'parent',ax3,'color',[0 0 0]), 
            line(o.x,I/Iamp*o.Nmax*1e-5,'parent',ax3,'color',[1 0.05 0.05]),
            line(o.t,o.detN*1e-5,'parent',ax4),
            drawnow  
        end
    end
    o.detN = o.detN*h/o.Nmax;
    return                      % 1D pump experiments do not use rest of code
end

% ######################
% Progatate pump and dynamics before THz probe pulse is launched
% ######################
if c.prop == 0
    disp('c.prop = 0, hence no propagation')
    return
end
for n = nattem:0
    if n < natten
        I = I0.*exp( -(Ik1 -Ik2*n).^2.*Ik3); % pump at time n
    elseif n == natten 
        I = zeros(Ms,1);            % pump is gone
    end
    m.N0 =  m.N;                    % store old density
    if c.diffusion == 1             % calculate using diffusion and surface recombination
        m.N(2:Ms-1) = dt.*m.y.*I(2:Ms-1) + m.N(2:Ms-1).*(1 - dt.*m.rb - 2.*dt./(h.^2).*m.D(2:Ms-1))... 
            + dt.*m.D(2:Ms-1)./(h.^2) .* ( m.N(3:Ms) + m.N(1:Ms-2) );
        m.N(Ms) = dt.*m.y.*I(Ms) + m.N0(Ms).*(1 - dt.*m.rb - dt./(h.^2).*m.D(Ms))...
            + dt.*m.D(Ms)./(h.^2) .* ( m.N0(Ms-1) ); 
        m.N(1) = dt.*m.y.*I(1) + m.N0(1).*(1-dt*m.rs/h - dt.*m.rb - dt./(h.^2).*m.D(1))...
            + dt.*m.D(1)./(h.^2) .* m.N0(2);
    else                            % do NOT calculate using diffusion and surface recombination
        m.N = dt.*m.y.*I + m.N.*(1 - dt.*m.rb);
    end
end

% ######################
% Progatate pump and dynamics
% ######################

for n = 1:c.Nt                          % time step   
% Source
% ######################
    S = SE(n);                          % set input in vector
    E(Msource) = E(Msource) + S;        % adding current source 
    H(Msource) = H(Msource) + c.Q*S;    % adding unidirectional propagation (needed to see the reflection)

% Pump
% ######################
    if n < natten
        I = I0.*exp( -(Ik1 -Ik2*n).^2.*Ik3); % pump at time n
    elseif n == natten
        I = zeros(Ms,1);                % pump is gone
    end
% Evolve carrier density dynamics
% ######################
    m.N0 =  m.N;                        % store old density
    if c.diffusion == 1                 % calculate using diffusion and surface recombination
        m.N(2:Ms-1) = dt.*m.y.*I(2:Ms-1) + m.N(2:Ms-1).*(1 - dt.*m.rb - 2.*dt./(h.^2).*m.D(2:Ms-1))... 
            + dt.*m.D(2:Ms-1)./(h.^2) .* ( m.N(3:Ms) + m.N(1:Ms-2) ); 
        m.N(Ms) = dt.*m.y.*I(Ms) + m.N0(Ms).*(1 - dt.*m.rb - dt./(h.^2).*m.D(Ms))...
            + dt.*m.D(Ms)./(h.^2) .* ( m.N0(Ms-1) ); 
        m.N(1) = dt.*m.y.*I(1) + m.N0(1).*(1-dt*m.rs/h - dt.*m.rb - dt./(h.^2).*m.D(1))...
            + dt.*m.D(1)./(h.^2) .* m.N0(2);

        m.xs = m.x.*m.N0.*(1 - dt.*m.rb);
        m.xs(2:Ms-1) = m.xs(2:Ms-1) + m.x(2:Ms-1).*m.N0(2:Ms-1).*( - 2.*dt./(h.^2).*m.D(2:Ms-1))... 
            + dt.*m.D(2:Ms-1)./(h.^2) .* ( m.x(3:Ms).*m.N0(3:Ms) + m.x(1:Ms-2).*m.N0(1:Ms-2) );%...
        m.xs(Ms) = m.xs(Ms) + m.x(Ms).*m.N0(Ms).*(- dt./(h.^2).*m.D(Ms))...
            + dt.*m.D(Ms)./(h.^2) .* (  m.x(Ms-1).*m.N0(Ms-1) ); 
        m.xs(1) = m.xs(1) + m.x(1).*m.N(1).*(-dt*m.rs/h - dt./(h.^2).*m.D(1))...
            + dt.*m.D(1)./(h.^2) .* m.N0(2).* m.x(2);

        m.x0s = m.x0.*m.N0.*(1 - dt.*m.rb);
        m.x0s(2:Ms-1) = m.x0s(2:Ms-1) + m.x0(2:Ms-1).*m.N0(2:Ms-1).*( - 2.*dt./(h.^2).*m.D(2:Ms-1))... 
            + dt.*m.D(2:Ms-1)./(h.^2) .* ( m.x0(3:Ms).*m.N0(3:Ms) + m.x0(1:Ms-2).*m.N0(1:Ms-2) );%...
        m.x0s(Ms) = m.x0s(Ms) + m.x0(Ms).*m.N0(Ms).*(- dt./(h.^2).*m.D(Ms))...
            + dt.*m.D(Ms)./(h.^2) .* (  m.x0(Ms-1).*m.N0(Ms-1) ); 
        m.x0s(1) = m.x0s(1) + m.x0(1).*m.N(1).*(-dt*m.rs/h - dt./(h.^2).*m.D(1))...
            + dt.*m.D(1)./(h.^2) .* m.N0(2).* m.x0(2);
    else                        % do NOT calculate using diffusion and surface recombination
        m.N = dt.*m.y.*I + m.N.*(1 - dt.*m.rb);
        m.xs = m.x.*m.N0.*(1 - dt.*m.rb);
        m.x0s = m.x0.*m.N0.*(1 - dt.*m.rb);
    end    

% Evolve x fields, displacement
% ######################
    J = zeros(c.Nh,1);              % polarization sum vector
    m.x1 = m.x0s./(m.N + eps);
    m.x0 = m.xs./(m.N + eps);
    m.x = m.al.*m.x0 + m.be.*m.x1 - m.th.*E(Mst:Mend);
    J(Mst:Mend) = (m.x.*m.N - m.x0.*m.N0).*eee(Mst:Mend);
    
% Evolve E field
% ######################
    E(1) = 1./App(1).*(Amm(1).*E(1) - c.Q./ep(1).*H(1)); % perfect magnetic conductor BC, left;
    E(2:c.Nh) = 1./App(2:c.Nh).*( Amm(2:c.Nh).*E(2:c.Nh) - c.Q./ep(2:c.Nh).*(H(2:c.Nh) - H(1:c.Nh-1)) ) + J(2:c.Nh);
    
% Evolve H field
% ######################
    H(1:c.Nh-1) = 1./AHpp(1:c.Nh-1).*( AHmm(1:c.Nh-1).*H(1:c.Nh-1) - c.Q.*( E(2:c.Nh) - E(1:c.Nh-1) ) );
    H(c.Nh) = 1./AHpp(c.Nh).*( AHmm(c.Nh).*H(c.Nh) + c.Q.*E(c.Nh) );% perfect electric conductor BC, right;

% Detector
% ######################
    if ~mod(n,Nskip)
        o.detR(n/Nskip) = E(c.Ah+c.sph+1);      % reflection detector
        o.detT(n/Nskip) = E(c.Nh-c.Ah-c.sph);   % transmission detector
        o.detJ(n/Nskip) = J(Mst+10);            % P detector
        o.detx(n/Nskip) = m.x(3);               % displacement detector
        o.detN(n/Nskip) = m.N(3);               % density
    end
    
% Plot 'realtime'
% ######################
    if ~mod(n,ps.real)
        cla(ax1),cla(ax2),cla(ax3),cla(ax4)
        line(o.z,E*sqrt(c.eps00)/(1.5*c.EA),'parent',ax1,'color',[0 0 0]),
        line(o.z,ep/c.eps00,'parent',ax1,'color',[0.05 0.05 1]),
        line(o.t,o.detR/(1.5*c.EA),'parent',ax2,'color',[1 0.05 0.05]),
        line(o.t,o.detT/(1.5*c.EA),'parent',ax2,'color',[0 0 0]),
        line(o.x,m.N*1e-5,'parent',ax3,'color',[0 0 0]), 
        line(o.x,I/Iamp*o.Nmax*1e-5,'parent',ax3,'color',[1 0.05 0.05]),
        line(o.t,o.detN*1e-5,'parent',ax4),
%         title(['Time step: ' num2str(n) '/' num2str(c.Nt) ' = ' num2str(dt*n*1e3,'%.0f') ' fs / ' num2str(tmax,'%.2f') ' ps'])
        drawnow  
    end
end

end % main function
