function [fdet fapr ftot ftotcut] = clrespfun(f)
%% FDTD-TRTS
% FDTD implementation of time-resolved THz-spectroscopy (TRTS)
% Developed by Casper Larsen, 2010, DTU, Denmark
% Please cite: "C. Larsen, D. Cooke, P. U. Jepsen, Finite-Difference
% Time-Domain Analysis of Time-resolved THz Spectroscopy Experiments, JOSA B 2011".
% See user manual for explanations and usage

% Calculates the response function
respCut = 3.7;  % cut off frequency of the detector response
dd = 5.15e-4;   % detector thickness in m
c = 299792458;  % light speed
delf = 6.8;     % bandwidth of visible probe in THz
ng = 3.24;      % group index
eps_el = 6.8;   % relative permittivity
eps_st = [0.0238 0.0941 3 0.008 0.0029 0.005];
Ome_TO = [1.6701 3.6027 5.45 7.18 8.97 10.52]; % in THz
gam =    [0.2531 0.5239 0.028 0.20 0.28 0.31]; % in THz
nt2 = eps_el;
for j = 1:length(eps_st)
    nt2 = nt2 + (eps_st(j)*Ome_TO(j)^2)./(Ome_TO(j)^2 - f.^2 - 2*1i*gam(j)*f);
end
nt = sqrt(nt2);
chi2 = nt.^2-1;                             % source: electro-optic detection of THz..
dk = 2.*pi.*1e12.*f/c.*(nt - ng);           % phase mismatch
fdet = (exp(i*dk*dd)-1)./(1i*dk) .* chi2 ;  % phasematching
fdet = fdet.*2./(1+nt);                     % transmission
fdet = fdet.*exp(-f.^2/(4*delf^2));         % autocorrelation
fdet = fdet/abs(fdet(find(f > 0,1,'first'))); % normalize
a = find(f > respCut,1,'first');
b = find(f < -respCut,1,'last');
fdetcut = fdet;
fdetcut([1:b a:end]) = fdet(a);
cuton = abs(fdet(a));
fdetcut(isnan(fdetcut)) = 1; % get rid of NaN at f = 0 THz
fdet(isnan(fdet)) = 1; % get rid of NaN at f = 0 THz

fapr = abs(erf(pi*f*200/300)).^2;           % aperture response function
faprcut = fapr;
faprcut(fapr<cuton) = cuton;                % cuton

ftot = fdet.*fapr;                          % total response
ftotcut = fdetcut.*faprcut;                 % total reponse with cutoff
