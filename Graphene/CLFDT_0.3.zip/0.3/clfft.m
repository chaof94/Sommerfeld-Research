function [f,F,absF,angF] = clfft(x,y,type,res,zpad)
%% FDTD-TRTS
% FDTD implementation of time-resolved THz-spectroscopy (TRTS)
% Developed by Casper Larsen, 2010, DTU, Denmark
% Please cite: "C. Larsen, D. Cooke, P. U. Jepsen, Finite-Difference
% Time-Domain Analysis of Time-resolved THz Spectroscopy Experiments, JOSA B 2011".
% See user manual for explanations and usage

% calculate fft and calculate time/frequency axis
% x = time vector
% y = signal, y(t,n) where n is parameter
% type: 'tf' (time to freq) or 'ft' (freq to time)
% res is the resolution
% zpad is the method of zeropadding, decay rate of exponential tail, default is 30
    a = size(y);
    if nargin == 3 % if res not set, find nearest power of 2
        res = 2^nextpow2(max(a));
    end
    if nargin <= 4 % if zeropaddeing decay not set
        zpad = 30;
    end
    if mod(res,2) > 0 % if res is odd make it even
        res = res + 1;
    end
    if a(1)<a(2) % if dim 1 > dim 2 do a transpose.
        y = y.';
    end
    if res > max(a) && ~strcmp(zpad,'nopadding')
        % zeropadding with exp tail
%         ap = 12; % e^-12 lower signal at decay length
        ap = zpad;
        zpl = (res-max(a))/2; % half of zero padding length
        y = [(exp( - ap/zpl*(zpl:-1:1) )).'*y(1,:); y; (exp( - ap/zpl*(1:zpl) )).'*y(end,:)];
    end

        df = length(x)/((max(x)-min(x))*res);
        f = linspace(-res/2*df,(res/2-1)*df,res);
        switch type
            case 'tf' % from time to frequency
                switch min(a)
                    case 1
                        F = fftshift(ifft(fftshift(y),res));
                        angF = unwrap(angle(F)); 
                    otherwise
                        F = fftshift(ifft(fftshift(y,1),res),1);
                        angF = unwrap(unwrap(angle(F),[],1),[],2); 
                end
            case 'ft' % from frequency to time
                switch min(a)
                    case 1
                        F = fftshift(fft(fftshift(y),res));
                        angF = unwrap(angle(F)); 
                    otherwise
                        F = fftshift(fft(fftshift(y,1),res),1);
                        angF = unwrap(unwrap(angle(F),[],1),[],2); 
                end
        end
        absF = abs(F);
end
