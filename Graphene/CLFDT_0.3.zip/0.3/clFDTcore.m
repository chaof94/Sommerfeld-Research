function [o] = clFDTcore(c,m,ps,tp,usepump)
%%
% FDTD implementation of time-resolved THz-spectroscopy (TRTS)
% Developed by Casper Larsen, 2010, DTU, Denmark
% Please cite: "C. Larsen, D. Cooke, P. U. Jepsen, Finite-Difference
% Time-Domain Analysis of Time-resolved THz Spectroscopy Experiments, JOSA B 2011".

if nargin > 3                       % enable parrallel 2D simulations
    c.tp = tp;
end
if nargin > 4                       % enable parrallel 2D simulations
    c.usepump = usepump;
end
o = struct;                         % output structure

% ######################
% Constants
% ######################
T = 300;                            % temperature in K
c0 = 299792458*1e-6;                % light speed, �m/ps
eps0 = 8.065618045839289;           % vacuum permittivity, �A^2 ps^4/me �m^3 (8.8541878176e-12 * 9.10938215e-31 * (1e6)^2* (1e12)^4 * (1e-6)^3)
e0 = 0.1602176487;                  % elementary charge, �A ps (1.602176487e-19*1e12*1e6)
me = 1;                             % electron mass, 1 me (9.10938215e-31 kg)
Vp = 1.097769292728596;             % voltage, me �m^2 / ps^3 �A,  [V] = kg m^2/s^3 A (1/9.10938215e-31 *1e6^2* 1e12^-3* 1e-6)
kb = 1.515635503336524e-5;          % boltzmann constant, me �m^2/ps^2 K, [kb]_SI = kg m^2 / s^2 K (1.3806503e-23 * 1/9.10938215e-31* 1e6^2* 1e-12^2)
hcon = 6.62606896e-022;             % planck constant in J ps (6.62606896e-34*1e12)
h = c.d/(c.Nh-2*c.Ah-6*c.sph);      % spatial step size, �m
dt = c.Q*h/c0;                      % time step size, ps
if c.xpmtype == 2 % 1D pump
    dt = dt*c.tpfac1D;              % increase time step by tpfac1D
end
tmax = dt*c.Nt;                     % propagation time, ps
zmax = h*c.Nh;                      % domain length, �m
np = length(m);                     % number of poles

% ######################
% Setup vectors and stuff 
% ######################
A = zeros(c.Nh,1);                  % PML vector
A(1:c.Ah) = c.Amax*(1- ((1:c.Ah)-1)./c.Ah).^c.Am;       % left part PML E
A(c.Nh-c.Ah+1:c.Nh) = c.Amax*((1:c.Ah)./c.Ah).^c.Am;    % right part PML E
App = 1+A;                          % puls PML E vector
Amm = 1-A;                          % minus PML E vector
AH = (A(2:c.Nh) + A(1:c.Nh-1))/2;   % PML H i+1/2
AH = [AH; AH(end)];           	    % PML H i+1/2 complete vector
AHpp = 1+AH;                        % puls PML H vector
AHmm = 1-AH;                        % minus PML H vector

o.t = linspace(0,tmax,c.Nsav);      % time vector of E, ps
o.z = linspace(0,zmax,c.Nh);        % position of E, �m
E = zeros(c.Nh,1);                  % electric field, Vp/�m
H = zeros(c.Nh,1);                  % magnetic field, 
o.detR = zeros(c.Nsav,1);           % reflection detector
o.detT = zeros(c.Nsav,1);           % transmission detector
o.detJ = zeros(c.Nsav,1);           % polarization detector
o.detx = zeros(c.Nsav,np);          % displacement detector
o.detN = zeros(c.Nsav,np);          % density detector

Mst = c.Ah+4*c.sph+1;               % start of medium
Mend = c.Nh-c.Ah-2*c.sph;           % end of medium
Ms = Mend-Mst+1;                    % size of medium
Msource = c.Ah+2*c.sph+1;           % position of source
prpp = zeros(np,np-1);              % density rate equation vector
Nskip = c.Nt/c.Nsav;                % store very Nskip time-steps

ep = c.epsin*ones(c.Nh,1);          % permittivity vector
ep(Mst:Mend) = c.eps00;             % setup permittivity vector from epsin
ep(Mend+1:c.Nh) = c.epsout;         % setup permittivity vector from epsout
eee = e0./(ep*eps0);                % response parameter

tl = linspace(0,tmax,c.Nt);         % long time vector, ps
if c.useEref == 1                   % use 'Eref.dat' as probe input
    tempdat = importdata('Eref.dat');                   % get data
    tEref = tempdat(:,1);           % time vector
    Eref = tempdat(:,2);            % E field vector
    SE = interp1(tEref+c.t0,Eref,tl,'spline',0);        % long input vector
    o.detI = interp1(tEref+c.t0,Eref,o.t,'spline',0);   % input vector at stored times
    c.EA = max(o.detI)/sqrt(c.eps00);
else                                % use exp * sin as probe input
    SE = c.EA.*sin( c.ome0*(tl-c.t0).*(1+c.chirp.*(tl-c.t0)) ).*exp(-(tl-c.t0).^2/(2*c.pulseW^2)); % long input vector
    o.detI = c.EA.*sin( c.ome0*(o.t-c.t0).*(1+c.chirp.*(o.t-c.t0)) ).*exp(-(o.t-c.t0).^2/(2*c.pulseW^2)); % input vector at stored times
end

% ######################
% Dynamic material and pump parameters
% ######################
o.Nmax = c.F * 1e-6*(1e-4)^2 *c.lamp* (1-c.Rpump) /(hcon*c0*c.abp); % maximum carrier density in �m^-3
Iamp = o.Nmax/(sqrt(pi)*c.pumpW*c.abp);                 % normalization factor of I
z0 = o.z(Mst);                                          % start position of medium
o.x = transpose(o.z(Mst:Mend)-z0);                      % reduced position vector
pumpWz = c0*c.pumpW/c.ng;                               % pump width in space
pumpprop = 10* max([c.abp pumpWz]);                     % length of propagation of pump
nattem = round(((-10*pumpWz-z0)*c.ng/c0 - c.tp + c.t0)/dt); % determines first time step with pump
natten = round(((pumpprop-z0)*c.ng/c0 - c.tp + c.t0)/dt);   % determines last time step with pump

Ik1 = o.x-c0/c.ng*(c.tp - c.t0);                        % Pump parameter 1
Ik2 = c0/c.ng*dt;                                       % Pump parameter 2
Ik3 = 1/pumpWz.^2;                                      % Pump parameter 3
I0 = c.usepump.*Iamp.*exp(-o.x/c.abp);                  % Setup pump vector
I = zeros(Ms,1);

% ######################
% Initiate material response 
% ######################
for p = 1:np
    m(p).N = m(p).y*o.Nmax*ones(Ms,1)*exp(-1);  % set density to maximum temporarily
    prpp(p,:) = [1:p-1 p+1:np];                 % density rate equation vector
    m(p).th0 = 2.*e0.*dt.^2./ m(p).meff ;       % theta parameter 
    m(p).D = m(p).D.*ones(Ms,1);                % diffusion constant, �m^2/ps
    m(p).g = m(p).g.*ones(Ms,1);                % electron scattering rate, ps^-1
    m(p).al = (4-2*m(p).w0^2*dt^2)./(2 + m(p).g*dt); % alpha parameter
    m(p).be = (m(p).g*dt-2)./(m(p).g.*dt+2);    % beta parameter
    m(p).mue = e0/(m(p).g(1).*m(p).meff);       % electron mobility (not used)
    m(p).muh = m(p).mue;                        % hole mobility (not used)
    m(p).th = m(p).th0./(2 + m(p).g.*dt);       % theta parameter
    m(p).x0 = zeros(Ms,1);                      % temporary displacement vector
    m(p).x = zeros(Ms,1);                       % current displacement vector
    m(p).N0 = zeros(Ms,1);                      % setup old density vector
end

% ######################
% Checks
% ######################
if ps.numpar == 1
    disp(['Nh: ' num2str(c.Nh) ', h: ' num2str(h*1e3) 'nm, Zmax: ' num2str(zmax) '�m, d: ' num2str(c.d) ...
            '�m | Nt: ' num2str(c.Nt) ', dt: ' num2str(dt*1e3) 'fs, Tmax: ' num2str(tmax) 'ps, df: ' num2str(1/tmax) 'THz']);
    for p = 1:np
        disp(['Term:' num2str(p) ', F: ' num2str(m(p).y*c.F) '�J/cm^2, Nmax: ' num2str(m(p).y*o.Nmax*1e12,'%.3g') 'cm^-3, mu_e: '...
            num2str(m(p).mue(1)*Vp*1e4,'%.4g') 'cm^2/Vs,  mu_h: ' num2str(m(p).muh(1)*Vp*1e4,'%.4g') 'cm^2/Vs, D: ' ...
            num2str(m(p).D(1)*1e4,'%.3g') 'cm^2/s, s: ' num2str(m(p).rs*1e8,'%.3g') 'cm/s, gamma: ' num2str(m(p).g(1),'%.3g')...
            'aTHz , w_p: ' num2str(sqrt(m(p).y*o.Nmax*e0^2/eps0/m(p).meff),'%.3g') 'aTHz']);
    end
end
if (max(m(p).rs)*dt/(2*h)) >= 1 
    disp('Surface recombination stability factor larger than 1')
    return
end
if (2*dt*max(m(p).D)/h^2) >= 1 
    disp('Diffusion stability factor larger than 1')
    return
end
if length(m(p).rpp) < np
    disp('"rpp" is missing some rates')
end
if Nskip < 1; c.Nsav = c.Nt; disp('Nsav > Nt'); end
if mod(Nskip,1) > 0, disp('Nt must be dividable with Nsav'), end
if c.xpmtype == 2 % 1D pump
    if nattem < 1
        disp(['c.tp must be smaller: ~' num2str(nattem*dt+c.tp) 'ps'])
        return
    end
    if c.diffusion == 0
        disp('In 1D pump experiments diffusion is needed!')
        return
    end
    if ps.numpar == 1
        disp(['Maximum dt: ~' num2str(min([2*h/max(m(1).rs) h^2/(2*max(m(1).D))])*1e3) ...
         'ps, pump propagates in: ' num2str(natten-nattem) ' steps'])
    end
end

% ######################
% Propagate system
% ######################
if ps.real > 0 && c.xpmtype ~= 3
    figure('Color',[1 1 1],'position',[100 100 800 600],'DefaultAxesColorOrder',...
       [0 0 0; 1 0.05 0.05; 0.05 0.05 0.9; 0.05 0.8 0.05; 0.4 0.4 0.4]);
    ax1 = subplot(2,2,1,'nextplot','replacechildren');
    xlabel('Position, �m')
    ylabel('Electric field and \epsilon(z)/ \epsilon_\infty')
    ylim([-1,1])
    xlim([0 max(o.z)])
    ax2 = subplot(2,2,2,'nextplot','replacechildren');
    xlabel('Time, ps')
    ylabel('Trans. and Reflec.')
    ylim([-1,1])
    xlim([0 max(o.t)])
    ax3 = subplot(2,2,3,'nextplot','replacechildren');
    xlabel('Position, �m')
    ylabel('Carrier Density, 10^{17} cm^{-3}')
%     ylim([0 1.1])
    xlim([0 max(o.x)])
    ax4 = subplot(2,2,4,'nextplot','replacechildren');
    xlabel('Time, ps')
    ylabel('Near Surface Carrier Density, 10^{17} cm^{-3}')
    if c.xpmtype == 2
        ylabel('Carrier Density \alpha \Delta T')
    end
%     ylim([0 1.1])
    xlim([0 max(o.t)])
end

% ######################
% Setup densities
% ######################
for p = 1:np                        % reset densities
    m(p).N = zeros(Ms,1);           % density
    if c.pumpexp == 1               % exponential decaying density in space
        m(p).N = m(p).y*o.Nmax*exp(-o.x/c.abp);
        if c.usepump == 1
            disp('conflict pumpexp and usepump')
        end
    end
    if c.densityconst == 1             % uniform density
        m(p).N = m(p).y*o.Nmax*ones(Ms,1);
        if c.usepump == 1
            disp('conflict densityconst and usepump')
        end
    end
end

% ######################
% Simulate 1D pump experiment
% ######################
if c.xpmtype == 2
    for n = 1:c.Nt
        if n < natten
            I = I0.*exp( -(Ik1 -Ik2*n).^2.*Ik3); % pump at time n
        elseif n == natten 
            I = zeros(Ms,1);    % pump is gone
        end
        for p = 1:np % density of poles, inc. pump, diffusion, decay, bulk and surface recomb.
            m(p).N0 =  m(p).N;  % store old density
            m(p).N(2:Ms-1) = dt.*m(p).y.*I(2:Ms-1) + m(p).N(2:Ms-1).*(1 - dt.*m(p).rb - 2.*dt./(h.^2).*m(p).D(2:Ms-1))... 
                + dt.*m(p).D(2:Ms-1)./(h.^2) .* ( m(p).N(3:Ms) + m(p).N(1:Ms-2) );%... 
            m(p).N(Ms) = dt.*m(p).y.*I(Ms) + m(p).N(Ms).*(1 - dt.*m(p).rb - dt./(h.^2).*m(p).D(Ms))...
                + dt.*m(p).D(Ms)./(h.^2) .* ( m(p).N0(Ms-1) ); 
            m(p).N(1) = dt.*m(p).y.*I(1) + m(p).N(1).*(1-dt*m(p).rs/h - dt.*m(p).rb - dt./(h.^2).*m(p).D(1))...
                + dt.*m(p).D(1)./(h.^2) .* m(p).N0(2);
            for pp = prpp(p,:) % decay between poles, did I say p?
                m(p).N =  m(p).N + dt.*( m(pp).N .*m(p).rpp(pp) - m(p).N .*m(pp).rpp(p)); 
            end
        end
        if ~mod(n,Nskip)
            for p = 1:np
                o.detT(n/Nskip) = o.detT(n/Nskip) + sum(m(p).N)./m(p).meff;  % spatial integral of density/effective mass detector
                o.detR(n/Nskip) = o.detR(n/Nskip) + m(p).N(1)./m(p).meff;    % surface density/effective mass detector
                o.detx(n/Nskip,p) = m(p).N(3);                               % surface density for each pole detector
                o.detN(n/Nskip,p) = sum(m(p).N);                             % spatial integral of density detector
            end
        end
        if ~mod(n,ps.real)
            cla(ax3),cla(ax4)
            line(o.x,I/Iamp*o.Nmax*1e-5,'parent',ax3,'color',[1 0.05 0.05]),
            for p = 1:np
                line(o.x,m(p).N*1e-5,'parent',ax3), 
                line(o.t,o.detN(:,p)*1e-5,'parent',ax4),
            end 
            drawnow  
        end
    end
    o.detT = o.detT*h/o.Nmax;
    o.detN = o.detN*h/o.Nmax;
    return                      % 1D pump experiments do not use rest of code
end

% ######################
% Progatate pump and dynamics before THz probe pulse is launched
% ######################
if c.prop == 0
    disp('c.prop = 0, hence no propagation')
    return
end
for n = nattem:0
    if n < natten
        I = I0.*exp( -(Ik1 -Ik2*n).^2.*Ik3); % pump at time n
    elseif n == natten 
        I = zeros(Ms,1);            % pump is gone
    end
    for p = 1:np    
        m(p).N0 =  m(p).N;          % store old density
        if c.diffusion == 1         % calculate using diffusion and surface recombination
            m(p).N(2:Ms-1) = dt.*m(p).y.*I(2:Ms-1) + m(p).N(2:Ms-1).*(1 - dt.*m(p).rb - 2.*dt./(h.^2).*m(p).D(2:Ms-1))... 
                + dt.*m(p).D(2:Ms-1)./(h.^2) .* ( m(p).N(3:Ms) + m(p).N(1:Ms-2) );
            m(p).N(Ms) = dt.*m(p).y.*I(Ms) + m(p).N0(Ms).*(1 - dt.*m(p).rb - dt./(h.^2).*m(p).D(Ms))...
                + dt.*m(p).D(Ms)./(h.^2) .* ( m(p).N0(Ms-1) ); 
            m(p).N(1) = dt.*m(p).y.*I(1) + m(p).N0(1).*(1-dt*m(p).rs/h - dt.*m(p).rb - dt./(h.^2).*m(p).D(1))...
                + dt.*m(p).D(1)./(h.^2) .* m(p).N0(2);
        else                        % do NOT calculate using diffusion and surface recombination
            m(p).N = dt.*m(p).y.*I + m(p).N.*(1 - dt.*m(p).rb);
        end
        for pp = prpp(p,:)          % decay between poles, did I say p?
            m(p).N =  m(p).N + dt.*( m(pp).N0 .*m(p).rpp(pp) - m(p).N0 .*m(pp).rpp(p)); 
        end
    end
end

% ######################
% Progatate pump and dynamics
% ######################

for n = 1:c.Nt                      % time step   
% Source
% ######################
    S = SE(n);                      % set input in vector
    E(Msource) = E(Msource) + S;    % adding current source 
    H(Msource) = H(Msource) + c.Q*S; % adding unidirectional propagation (needed to see the reflection)

% Pump
% ######################
    if n < natten
        I = I0.*exp( -(Ik1 -Ik2*n).^2.*Ik3); % pump at time n
    elseif n == natten
        I = zeros(Ms,1);            % pump is gone
    end
% Evolve carrier density dynamics
% ######################
    for p = 1:np    
        m(p).N0 =  m(p).N;          % store old density
        if c.diffusion == 1         % calculate using diffusion and surface recombination
            m(p).N(2:Ms-1) = dt.*m(p).y.*I(2:Ms-1) + m(p).N(2:Ms-1).*(1 - dt.*m(p).rb - 2.*dt./(h.^2).*m(p).D(2:Ms-1))... 
                + dt.*m(p).D(2:Ms-1)./(h.^2) .* ( m(p).N(3:Ms) + m(p).N(1:Ms-2) ); 
            m(p).N(Ms) = dt.*m(p).y.*I(Ms) + m(p).N0(Ms).*(1 - dt.*m(p).rb - dt./(h.^2).*m(p).D(Ms))...
                + dt.*m(p).D(Ms)./(h.^2) .* ( m(p).N0(Ms-1) ); 
            m(p).N(1) = dt.*m(p).y.*I(1) + m(p).N0(1).*(1-dt*m(p).rs/h - dt.*m(p).rb - dt./(h.^2).*m(p).D(1))...
                + dt.*m(p).D(1)./(h.^2) .* m(p).N0(2);
            
            m(p).xs = m(p).x.*m(p).N0.*(1 - dt.*m(p).rb);
            m(p).xs(2:Ms-1) = m(p).xs(2:Ms-1) + m(p).x(2:Ms-1).*m(p).N0(2:Ms-1).*( - 2.*dt./(h.^2).*m(p).D(2:Ms-1))... 
                + dt.*m(p).D(2:Ms-1)./(h.^2) .* ( m(p).x(3:Ms).*m(p).N0(3:Ms) + m(p).x(1:Ms-2).*m(p).N0(1:Ms-2) );%...
            m(p).xs(Ms) = m(p).xs(Ms) + m(p).x(Ms).*m(p).N0(Ms).*(- dt./(h.^2).*m(p).D(Ms))...
                + dt.*m(p).D(Ms)./(h.^2) .* (  m(p).x(Ms-1).*m(p).N0(Ms-1) ); 
            m(p).xs(1) = m(p).xs(1) + m(p).x(1).*m(p).N(1).*(-dt*m(p).rs/h - dt./(h.^2).*m(p).D(1))...
                + dt.*m(p).D(1)./(h.^2) .* m(p).N0(2).* m(p).x(2);

            m(p).x0s = m(p).x0.*m(p).N0.*(1 - dt.*m(p).rb);
            m(p).x0s(2:Ms-1) = m(p).x0s(2:Ms-1) + m(p).x0(2:Ms-1).*m(p).N0(2:Ms-1).*( - 2.*dt./(h.^2).*m(p).D(2:Ms-1))... 
                + dt.*m(p).D(2:Ms-1)./(h.^2) .* ( m(p).x0(3:Ms).*m(p).N0(3:Ms) + m(p).x0(1:Ms-2).*m(p).N0(1:Ms-2) );%...
            m(p).x0s(Ms) = m(p).x0s(Ms) + m(p).x0(Ms).*m(p).N0(Ms).*(- dt./(h.^2).*m(p).D(Ms))...
                + dt.*m(p).D(Ms)./(h.^2) .* (  m(p).x0(Ms-1).*m(p).N0(Ms-1) ); 
            m(p).x0s(1) = m(p).x0s(1) + m(p).x0(1).*m(p).N(1).*(-dt*m(p).rs/h - dt./(h.^2).*m(p).D(1))...
                + dt.*m(p).D(1)./(h.^2) .* m(p).N0(2).* m(p).x0(2);
        else                        % do NOT calculate using diffusion and surface recombination
            m(p).N = dt.*m(p).y.*I + m(p).N.*(1 - dt.*m(p).rb);
            m(p).xs = m(p).x.*m(p).N0.*(1 - dt.*m(p).rb);
            m(p).x0s = m(p).x0.*m(p).N0.*(1 - dt.*m(p).rb);
        end    
        for q = prpp(p,:)           % decay between poles
            m(p).N =  m(p).N + dt.*( m(q).N0 .*m(p).rpp(q) - m(p).N0 .*m(q).rpp(p)); 
            m(p).xs =  m(p).xs + dt.*( m(q).x.*m(q).N0 .*m(p).rpp(q) - m(p).x.*m(p).N0 .*m(q).rpp(p)); 
            m(p).x0s =  m(p).x0s + dt.*( ( m(q).x.*( 1-m(q).meff/m(p).meff )...
                + m(q).x0.*m(q).meff/m(p).meff) .*m(q).N0 .*m(p).rpp(q) - m(p).x0.*m(p).N0 .*m(q).rpp(p)); 
        end
    end

% Evolve x fields, displacement
% ######################
    J = zeros(c.Nh,1);              % polarization sum vector
    for p = 1:np
        m(p).x1 = m(p).x0s./(m(p).N + eps);
        m(p).x0 = m(p).xs./(m(p).N + eps);
        m(p).x = m(p).al.*m(p).x0 + m(p).be.*m(p).x1 - m(p).th.*E(Mst:Mend);
        J(Mst:Mend) = J(Mst:Mend) + (m(p).x.*m(p).N - m(p).x0.*m(p).N0);
    end
    J = J.*eee;
    
% Evolve E field
% ######################
    E(1) = 1./App(1).*(Amm(1).*E(1) - c.Q./ep(1).*H(1)); % perfect magnetic conductor BC, left;
    E(2:c.Nh) = 1./App(2:c.Nh).*( Amm(2:c.Nh).*E(2:c.Nh) - c.Q./ep(2:c.Nh).*(H(2:c.Nh) - H(1:c.Nh-1)) ) + J(2:c.Nh);
    
% Evolve H field
% ######################
    H(1:c.Nh-1) = 1./AHpp(1:c.Nh-1).*( AHmm(1:c.Nh-1).*H(1:c.Nh-1) - c.Q.*( E(2:c.Nh) - E(1:c.Nh-1) ) );
    H(c.Nh) = 1./AHpp(c.Nh).*( AHmm(c.Nh).*H(c.Nh) + c.Q.*E(c.Nh) );% perfect electric conductor BC, right;

% Detector
% ######################
    if ~mod(n,Nskip)
        o.detR(n/Nskip) = E(c.Ah+c.sph+1);      % reflection detector
        o.detT(n/Nskip) = E(c.Nh-c.Ah-c.sph);   % transmission detector
        o.detJ(n/Nskip) = J(Mst+10);            % P detector
        for p = 1:np
            o.detx(n/Nskip,p) = m(p).x(3);      % displacement detector
            o.detN(n/Nskip,p) = m(p).N(3);      % density
        end
    end
    
% Plot 'realtime'
% ######################
    if ~mod(n,ps.real)
        cla(ax1),cla(ax2),cla(ax3),cla(ax4)
        line(o.z,E/(1.5*c.EA),'parent',ax1,'color',[0 0 0]),
        line(o.z,ep/c.eps00,'parent',ax1,'color',[0.05 0.05 1]),
        line(o.t,o.detR/(1.5*c.EA),'parent',ax2,'color',[1 0.05 0.05]),
        line(o.t,o.detT/(1.5*c.EA),'parent',ax2,'color',[0 0 0]),
        line(o.x,I/Iamp*o.Nmax*1e-5,'parent',ax3,'color',[1 0.05 0.05]),
        for p = 1:np
            line(o.x,m(p).N*1e-5,'parent',ax3), 
        end
        line(o.t,o.detN*1e-5,'parent',ax4),
%         title(['Time step: ' num2str(n) '/' num2str(c.Nt) ' = ' num2str(dt*n*1e3,'%.0f') ' fs / ' num2str(tmax,'%.2f') ' ps'])
        drawnow  
    end
end
end % main function