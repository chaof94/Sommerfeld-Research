function [] = clFDTplot(c,m,ps,o)
%% FDTD-TRTS
% FDTD implementation of time-resolved THz-spectroscopy (TRTS)
% Developed by Casper Larsen, 2010, DTU, Denmark
% Please cite: "C. Larsen, D. Cooke, P. U. Jepsen, Finite-Difference
% Time-Domain Analysis of Time-resolved THz Spectroscopy Experiments, JOSA B 2011".
% See user manual for explanations and usage

    % If batch-simulation, then plot all of them
    no = length(o);
    for j = 1:no
        clsubplots(c,m,ps,o(j))
    end
end

function clsubplots(c,m,ps,o)
    switch c.xpmtype
        case 1 % 1D probe
            if ps.plot == 1; % analyze simulation
                figure,
                subplot(2,2,[1 2])
                plot(o.t,o.detI,o.t,o.detR,o.t,o.detT,o.t,o.detN/o.Nmax*c.EA)
                xlim([0,max(o.t)])
                xlabel('Time, ps')
                ylabel('ab.units')
                legend('E_{in}','E_{R}','E_{T}','N_{surf}')

                [f,FI,absFI,angFI] = clfft(o.t,o.detI,'tf',ps.Nfft);
                [f,FR,absFR,angFR] = clfft(o.t,o.detR,'tf',ps.Nfft);
                [f,FT,absFT,angFT] = clfft(o.t,o.detT,'tf',ps.Nfft);
                T = absFT./absFI;
                R = absFR./absFI;

                disp(['df: ' num2str(f(2)-f(1))])

                subplot(223)
                plot(f,10*log10(absFI),f,10*log10(absFR),f,10*log10(absFT));
                xlim(ps.fxlim)
                xlabel('Frequency, THz')
                ylabel('E(f), dB')
                legend('E_{in}','E_{R}','E_{T}')

                subplot(224)
                plot(f,R.^2,f,T.^2*sqrt(c.epsout));
                xlim(ps.fxlim)
                ylim([0,1])
                xlabel('Frequency, THz')
                legend('Reflectance','Transmittance')
            end
            if ps.plot == -1 % evaluate loss
                loss = -10*log10( sum(o.detI.^2) / sum(o.detR.^2) );
                disp(['Loss in dB: ' num2str( -loss )])
            end
    % #########################################################################
        case 2 % 1D pumpe
            if ps.plot == 1
                figure
                subplot(211)
                plot(o.t,o.detN)
                title('Spatial integral of the density \alpha -\Delta T')
                xlabel('Time, ps')
                ylabel('Normalized carriers')            
                xlim([min(o.t) max(o.t)])
                subplot(212)
                plot(o.t,o.detx*1e12)
                title('Near surface density')
                xlabel('Time, ps')
                ylabel('Density, cm^{-3}')
                xlim([min(o.t) max(o.t)])
            end
    % #########################################################################
        case 3 % 2D
            if ps.plot == 1
                figcon = figure;
                nlines = 20;
                nskip =1;
                viewposT = [31.5 34];
                ylabelrot = -45;
                o.detT2Dref = o.detT*ones(1,c.Ntp);
                o.DdetT2D = o.detT2D-o.detT2Dref; % differential transmission in pump-emitter
                o.DdetT2Dfix = zeros(size(o.DdetT2D));              
                for j = 1:c.Nsav % convert/numerical projection from pump-emitter to pump-sampling representation
                    o.DdetT2Dfix(j,:) = interp1(o.vtp-0+o.t(j),o.DdetT2D(j,:),o.vtp,'linear',0);
                end
                o.detT2Dfix = o.DdetT2Dfix+o.detT2Dref; % differential transmission fixed in pump-sampling
                [o.f,o.Ewr,o.absEwr,o.phaEwr] = clfft(o.t,o.detT2Dref,'tf',ps.Nfft);
                [o.f,o.Ewp,o.absEwp,o.phaEwp] = clfft(o.t,o.detT2Dfix,'tf',ps.Nfft);
                o.T = o.absEwp ./ o.absEwr; % transmission
                o.Phi = unwrap(o.phaEwp - o.phaEwr,[],2); % phase and unwrap across tp
                o.nnumin = find(o.f >= ps.fxlim(1),1,'first');
                o.nnumax = find(o.f >= ps.fxlim(2),1,'first');
                o.vecnu = o.nnumin:o.nnumax;
                o.fnu = o.f(o.vecnu);

                subplot(221)
                hold all, grid on 
                contour(o.t,o.vtp,-o.DdetT2D.',nlines);
                colormap(gray(8))
                xlabel('THz delay t, ps')
                ylabel('Pump-emitter delay t_{pe}, ps')
                set(gca,'DataAspectRatio',[1 1 1],...
                    'DataAspectRatioMode','manual')
                title('-\Delta E(t,t_{pe})')

                subplot(222)
                hold all, grid on 
                contour(o.t,o.vtp,-o.DdetT2Dfix.',nlines);
                xlabel('THz delay t, ps')
                ylabel('Pump-sampling delay t_p, ps')
                set(gca,'DataAspectRatio',[1 1 1],...
                    'DataAspectRatioMode','manual')
                title('-\Delta E(t,t_{p})')
                colorbar('location','East')

                a1 = subplot(2,2,3,'Parent',figcon);
                hold all, grid on 
                surf(o.vtp(1:nskip:end),o.fnu(1:nskip:end),o.T(o.vecnu(1:nskip:end),1:nskip:end),...
                    'Parent',a1,'FaceColor',[1 1 1]),
                view(viewposT);
                zlabel('T(\omega)')
                ylabel('Frequency, THz','Rotation',-ylabelrot)
                xlabel('t_p, ps')
                xlim([min(o.vtp) max(o.vtp)])
                ylim([min(o.fnu) max(o.fnu)])

                a2 = subplot(2,2,4,'Parent',figcon);
                hold all, grid on 
                surf(o.vtp(1:nskip:end),o.fnu(1:nskip:end),-o.Phi(o.vecnu(1:nskip:end),1:nskip:end),...
                    'Parent',a2,'FaceColor',[1 1 1]),
                view(viewposT);
                zlabel('-\Phi(\omega)')
                ylabel('Frequency, THz','Rotation',-ylabelrot)
                xlabel('t_p, ps')
                xlim([min(o.vtp) max(o.vtp)])
                ylim([min(o.fnu) max(o.fnu)])
            end
            if ps.plot == 2 % convolute
                figcon = figure;
                nlines = 20;
                nskip =1;
                viewposT = [31.5 34];
                ylabelrot = -45;
                o.detT2Dref = o.detT*ones(1,c.Ntp);     % Eref(t,tpp)
                o.DdetT2D = o.detT2D-o.detT2Dref;       % DEpump(t,tpp)
                o.DdetT2Dfix = zeros(size(o.DdetT2D));  % DEpump(t,tp)            
                for j = 1:c.Nsav % convert/numerical projection from pump-probe to pump-sampling representation
                    o.DdetT2Dfix(j,:) = interp1(o.vtp-0+o.t(j),o.DdetT2D(j,:),o.vtp,'linear',0);
                end
                o.detT2Dfix = o.DdetT2Dfix+o.detT2Dref; % Epump(t,tp)
                [o.f,o.Ewr,o.absEwr,o.phaEwr] = clfft(o.t,o.detT2Dref,'tf',ps.Nfft); % Eref(w,tp)
                [o.f,o.Ewp,o.absEwp,o.phaEwp] = clfft(o.t,o.detT2Dfix,'tf',ps.Nfft); % Epump(w,tp)
                [o.f,o.detTw,o.absdetTw,o.phadetTw] = clfft(o.t,o.detT,'tf',ps.Nfft);
                o.T = o.absEwp ./ o.absEwr;                 % transmission
                o.Phi = unwrap(o.phaEwp - o.phaEwr,[],2);   % phase and unwrap across tp
                
                [fdet fapr ftot ftotcut] = clrespfun(o.f);
                
                mresp = ftot.'*ones(1,c.Ntp);               % create response function matrix, ftot
                [o.f,o.Ewpg,o.absEwpg,o.phaEwpg] = clfft(o.t,o.detT2D,'tf',ps.Nfft); % Epump(w,tpp)
                [o.t2,o.CdetT2D,o.absCdetT2D,o.phaCdetT2D] = clfft(o.f,o.Ewpg.*mresp,'ft',ps.Nfft);   % Epumpcon=[ftot*Epump(w,tpp)](t)
                [o.t2,o.CdetT,o.absCdetT,o.phaCdetT] = clfft(o.f,o.detTw.*ftot.','ft',ps.Nfft);     % Erefcon=[ftot*Eref(w,tpp)](t)
                o.CdetT2Dref = o.CdetT*ones(1,c.Ntp); %ref 2D
                o.t2 = o.t2 + (max(o.t)+2*min(o.t))/2;
                o.CDdetT2D = o.CdetT2D - o.CdetT2Dref;      % DEcon(t,tpp)
                o.CDdetT2Dfix = zeros(size(o.CDdetT2D));  % DEpump(t,tp)            
                for j = 1:ps.Nfft % convert/numerical projection from pump-probe to pump-sampling representation
                    o.CDdetT2Dfix(j,:) = interp1(o.vtp-0+o.t2(j),real(o.CDdetT2D(j,:)),o.vtp,'linear',0);
                end
                o.CdetT2Dfix = o.CDdetT2Dfix+o.CdetT2Dref;  % Epumpcon(t,tp)
                [o.f,o.CdetTw,o.absCdetTw,o.phaCdetTw] = clfft(o.t2,o.CdetT,'tf',ps.Nfft); % ref, w, conv
                o.CEwr = o.CdetTw*ones(1,c.Ntp);      %2D ref,w, conv
                o.absCEwr = o.absCdetTw*ones(1,c.Ntp);
                o.phaCEwr = o.phaCdetTw*ones(1,c.Ntp);
                [o.f,o.CEwp,o.absCEwp,o.phaCEwp] = clfft(o.t2,o.CdetT2Dfix,'tf',ps.Nfft); % Epumpcon(w,tp)
                o.CT = o.absCEwp ./ o.absCEwr; % transmission, con
                o.CPhi = unwrap(o.phaCEwp - o.phaCEwr,[],2); % phase and unwrap across tp, con

                o.nnumin = find(o.f >= ps.fxlim(1),1,'first');
                o.nnumax = find(o.f >= ps.fxlim(2),1,'first');
                o.vecnu = o.nnumin:o.nnumax;
                o.fnu = o.f(o.vecnu);
                
                o.CPhi = o.CPhi-round(mean(mean(o.CPhi(o.vecnu,:)))/(2*pi))*2*pi;
                
                subplot(221)
                hold all, grid on 
                contour(o.t2,o.vtp,-o.CDdetT2D.',nlines);
%                 contour(o.t,o.vtp,-o.DdetT2D.',nlines);
                colormap(gray(8))
                xlim([min(o.t) max(o.t)])
                xlabel('THz delay t, ps')
                ylabel('Pump-emitter delay t_{pe}, ps')
                set(gca,'DataAspectRatio',[1 1 1],...
                    'DataAspectRatioMode','manual')
                title('-\Delta E(t,t_{pe})')

                subplot(222)
                hold all, grid on 
                contour(o.t2,o.vtp,-o.CDdetT2Dfix.',nlines);
                xlim([min(o.t) max(o.t)])
                xlabel('THz delay t, ps')
                ylabel('Pump-sampling delay t_p, ps')
                set(gca,'DataAspectRatio',[1 1 1],...
                    'DataAspectRatioMode','manual')
                title('-\Delta E(t,t_{p})')
                colorbar('location','East')

                a1 = subplot(2,2,3,'Parent',figcon);
                hold all, grid on 
                surf(o.vtp(1:nskip:end),o.fnu(1:nskip:end),o.CT(o.vecnu(1:nskip:end),1:nskip:end),...
                    'Parent',a1,'FaceColor',[1 1 1]),
                view(viewposT);
                zlabel('T(\omega)')
                ylabel('Frequency, THz','Rotation',-ylabelrot)
                xlabel('t_p, ps')
                xlim([min(o.vtp) max(o.vtp)])
                ylim([min(o.fnu) max(o.fnu)])

                a2 = subplot(2,2,4,'Parent',figcon);
                hold all, grid on 
                surf(o.vtp(1:nskip:end),o.fnu(1:nskip:end),-o.CPhi(o.vecnu(1:nskip:end),1:nskip:end),...
                    'Parent',a2,'FaceColor',[1 1 1]),
                view(viewposT);
                zlabel('-\Phi(\omega)')
                ylabel('Frequency, THz','Rotation',-ylabelrot)
                xlabel('t_p, ps')
                xlim([min(o.vtp) max(o.vtp)])
                ylim([min(o.fnu) max(o.fnu)])
            end
    end
end