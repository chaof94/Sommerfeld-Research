%% FDTD-TRTS
% FDTD implementation of time-resolved THz-spectroscopy (TRTS)
% Developed by Casper Larsen, 2010, DTU, Denmark
% Please cite: "C. Larsen, D. Cooke, P. U. Jepsen, Finite-Difference
% Time-Domain Analysis of Time-resolved THz Spectroscopy Experiments, JOSA B 2011".
% See user manual for explanations and usage

% load data
tempdat = importdata('Erefraw.txt');
fftres=2^12;
t = tempdat(:,1);
Eref = tempdat(:,2);
[f,Ew,absEwr,phaEwr] = clfft(t,Eref,'tf',fftres);
figure,
subplot(211)
plot(t,Eref)
xlabel('Time, ps')
ylabel('Electric field, ab. units.')
subplot(212)
plot(f,log10(abs(Ew)))
xlabel('Frequency, THz')
ylabel('Log10 ( E(\Omega/2\pi )')
xlim([0,3])
%% deconvolute
[f,Ewr,absEwr,phaEwr] = clfft(t,Eref,'tf',fftres);
[t2,Etr2,absEtr2,phaEtr2] = clfft(f,Ewr,'ft',fftres); % calc time signal  

[fdet fapr ftot ftotcut] = clrespfun(f);

CEwr = Ewr./ftotcut.';
CCEwr = CEwr.*(ftot).';
[t2,CEtr,CabsEtr,CphaEtr] = clfft(f,CEwr,'ft',fftres); % calc time signal
[t3,CCEtr,CCabsEtr,CCphaEtr] = clfft(f,CCEwr,'ft',fftres); % calc time signal
t2 = t2 + (max(t)+2*min(t))/2;

figure,
hold all
plot(t,Eref,'g')
plot(t2,real(Etr2),'r')
plot(t2,real(CCEtr),'Marker','+','LineStyle','none')
plot(t2,real(CEtr),'-b') 
legend('measured','IFFT-FFT-measured','Deconv. & conv.','Deconv.')
xlabel('Time, ps')
ylabel('Electric field, ab. units.')
xlim([0 4]);

%% make zero at edges and save
t2min = -max(t)/2;
it2min = find(0 <= t2,1,'first');
it2max = find(max(t)<= t2,1,'first');
t22 = t2(it2min:it2max);
Eref2 = 100*real(CEtr(it2min:it2max))/max(real(CEtr));
int = 15;
Eref3 = Eref2;
Eref3(1:int) = Eref2(1:int)'.*exp( - 2/int*(int:-1:1) );
Eref3(end-int+1:end) = Eref2(end-int+1:end)'.*exp( - 2/int*(1:int) );
figure,plot(t,Eref,t22,Eref2,t22,Eref3)
xlabel('Time, ps')
ylabel('Electric field, ab. units.')
legend('Measured','Deconvoluted','Deconvoluted and decaying at edges')
dlmwrite('Eref_new.dat', [t22' Eref3], 'delimiter', '\t', 'precision', 5);