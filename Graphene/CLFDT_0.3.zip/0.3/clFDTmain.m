function [o] = clFDTmain(c,m,ps) 
%% FDTD-TRTS
% FDTD implementation of time-resolved THz-spectroscopy (TRTS)
% Developed by Casper Larsen, 2010, DTU, Denmark
% Please cite: "C. Larsen, D. Cooke, P. U. Jepsen, Finite-Difference
% Time-Domain Analysis of Time-resolved THz Spectroscopy Experiments, JOSA B 2011".
% See user manual for explanations and usage
    uselite = clfinduselite(c,m);
    if uselite == 1
        disp('The lite version is used to increase efficiency.')
        [o] = clFDTmainlite(c,m,ps);% call main function 
    else
        c = clfindvp(c,m,ps); % enable batch calculations
        tic % Record time
        switch c.xpmtype % execute subfunctions
            case 1 % 1D probe experiment
                [o] = FDT1Dprobe(c,m,ps);   
            case 2 % 1D pump experiment
                [o] = FDT1Dpump(c,m,ps); 
            case 3 % 2D pump probe experiment
                [o] = FDT2Dpumpprobe(c,m,ps);
        end
        toc % Display time of calculation
        if c.save == 1
            t = clock;
            idclock = sprintf('-%0.4d-%0.2d-%0.2d-%0.2d-%0.2d', t(1), t(2), t(3), t(4), t(5));
            save([c.xpmid idclock '.mat'],'c','m','ps','o')
        end
        if ps.plot ~= 0 && c.prop == 1
            clFDTplot(c,m,ps,o); % plot
        end
    end
end

%% Subfunctions

function uselite = clfinduselite(c,m)
    % use the faster code (lite) 
        % if only one material
        % numerical input pulse
        % no use of batch simulation e.g. c.F = [1;2;3]
    uselite = 1; 
    if ( sum( (c.useEref == 1) + (length(m) > 1)) >=1 )
        uselite = 0;
    end
    if length(m) < 2
        fdc = fieldnames(c);
        for j = 1:length(fdc)
            if size(c.(fdc{j}),1) > 1
                uselite = 0;
            end
        end
        fdm = fieldnames(m);
        for j = 1:length(length(fdm))
            if size(m.(fdm{j}),1) > 1
                uselite = 0;
            end
        end
    end
end

function c = clfindvp(c,m,ps)
    nvar = 0;
    fdc = fieldnames(c);
    for j = 1:length(fdc)
        if size(c.(fdc{j}),1) > 1
            nvar = nvar + 1;
            disp(['"' fdc{j} '" is found as the variable parameter']);
            vp = [1 j 1]; % [struct# entry structure_index]
        end
    end
    fdm = fieldnames(m);
    np = length(m);
    for j = 1:length(fdm)
        for p = 1:np
            if size(m(p).(fdm{j}),1) > 1
                nvar = nvar + 1;
                vp = [2 j p]; % [struct# entry structure_index]
                disp(['"' fdm{j} '" is found as the variable parameter']);
            end
        end
    end
    if nvar > 1
        disp('############ Only one variable parameter is allowed - choose one! (check orientation of non-variable vectors)')
        return
    end
    if nvar == 0
        if ps.numpar ==1
            disp('No variable parameters entered, continuing...')
        end
        vp(1) = 0;
        varvec = 0;
        vpfname = '';
    end
    if vp(1) == 1;
        varvec = c.(fdc{vp(2)});
        vpfname = fdc{vp(2)};
    end
    if vp(1) == 2;
        varvec = m(vp(3)).(fdm{vp(2)});
        vpfname = fdm{vp(2)};
    end
    c.nvar = nvar;
    c.vp = vp;
    c.vpfname = vpfname;
    c.varvec = varvec;
    c.nvp = size(c.varvec,1);
end

function [o] = FDT1Dprobe(c,m,ps)
    v = struct;
    for jj = 1:c.nvp
        if c.nvar > 0
            if c.vp(1) == 1;
                c.(c.vpfname) = c.varvec(jj,:);
            end
            if c.vp(1) == 2;
                m(c.vp(3)).(c.vpfname) = c.varvec(jj,:);
            end 
        end
        [o] = clFDTcore(c,m,ps);
        if c.nvar > 0
            o.varpar = c.varvec(jj,:);
            v(jj).o = o;
        end
    end       
    if c.nvar > 0
        for jj = 1:size(c.varvec,1)
            o(jj) = v(jj).o;
        end
    end
end

function [o] = FDT1Dpump(c,m,ps)
    v = struct;
    for jj = 1:c.nvp
        if c.nvar > 0
            if c.vp(1) == 1;
                c.(c.vpfname) = c.varvec(jj,:);
            end
            if c.vp(1) == 2;
                m(c.vp(3)).(c.vpfname) = c.varvec(jj,:);
            end 
        end
        [o] = clFDTcore(c,m,ps);
        if c.nvar > 0
            o.varpar = c.varvec(jj,:);
            v(jj).o = o;
        else
            o.varpar = [];
        end
    end       
    if c.nvar > 0
        for jj = 1:size(c.varvec,1)
            o(jj) = v(jj).o;
        end
    end
end

function [o] = FDT2Dpumpprobe(c,m,ps)
    ps.real = 0; ps.numpar = 0;
    v = struct;
    vtp = linspace(c.mintp,c.maxtp,c.Ntp);
    if c.parallel == 1
        matlabpool; % initiate parallel processing
    end
    for jj = 1:c.nvp
        if c.nvar > 0
            if c.vp(1) == 1;
                c.(c.vpfname) = c.varvec(jj,:);
            end
            if c.vp(1) == 2;
                m(c.vp(3)).(c.vpfname) = c.varvec(jj,:);
            end 
        end
        detT2D = zeros(c.Nsav,c.Ntp);
        detR2D = zeros(c.Nsav,c.Ntp);
        parfor j = 1:c.Ntp % propagate 2D
            [to] = clFDTcore(c,m,ps,vtp(j));
            detT2D(:,j) = to.detT;
            detR2D(:,j) = to.detR;
        end
        [o] = clFDTcore(c,m,ps,min(vtp),0);
        o.detT2D = detT2D; % 2d transmission
        o.detR2D = detR2D; % 2d reflection
        o.vtp = vtp;
        if c.nvar > 0
            o.varpar = c.varvec(jj,:);
            v(jj).o = o;
        else
            o.varpar = [];
        end
    end       

    if c.nvar > 0
        for jj = 1:c.nvp
            o(jj) = v(jj).o;
        end
    end
    if c.parallel == 1;    
        matlabpool close % close parallel processing
    end
end

