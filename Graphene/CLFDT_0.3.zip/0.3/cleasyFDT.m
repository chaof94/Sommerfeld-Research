%% FDTD-TRTS
% FDTD implementation of time-resolved THz-spectroscopy (TRTS)
% Developed by Casper Larsen, 2010, DTU, Denmark
% Please cite: "C. Larsen, D. Cooke, P. U. Jepsen, Finite-Difference
% Time-Domain Analysis of Time-resolved THz Spectroscopy Experiments, JOSA B 2011".
% See user manual for explanations and usage

% This version is simplified only to handle diffusion, bulk and surface 
% recombination of a single density of a Drude/Lorentz dispersive term.

Nh = 2^9;           % spatial domain resolution
Nt = 2^11;          % time steps
Q = 1;              % FDTD quality factor
ome0 = 5 *2*pi;     % center frequency pulse, THz
pulseW = 10/ome0;   % envelope of pulse in time, ps
EA = 100;           % amplitude of pulse, ab.unit
t0 = 1;             % launch time of pulse, ps
d = 500;            % thickness of simulated region, mum
eps00 = 13;         % background refractive index, GaAs n = 3.6^2;
Nmax = 1e5;         % density of free electrons, mum^-3
g = 0.5 *2*pi;      % electron scattering rate, ps^-1
rb = 0.01;          % bulk recombination rate, ps^-1
w0 = 5*2*pi;        % resonance frequency, ps^-1
meff = 1;           % effective electron mass, meff*me = me*
rs = 1;             % surface recombination velocity, mum/ps  
D = 50;             % diffusion coefficient, mum^2/ps
abp = 100;          % absorption depth, mum
Mst = 100;          % medium surface
Amax = 0.186;       % absorption coefficient of PML
Am = 1.429;         % PML m parameter
Ah = 20;            % width of PML
c0 = 300;           % light speed, mum/ps
e0 = 0.16;          % electronic charge, muAps
eps0 = 8.0657;      % vacuum permittivity, muA^2 ps^4/me mum^3
h = d/Nh;           % spatial step size, mum
dt = Q*h/c0;        % time step size, ps
% Initiate material response 
A = zeros(Nh,1);    % PML vector
A(1:Ah) = Amax*(1- ((1:Ah)-1)./Ah).^Am; % left part PML E
A(Nh-Ah+1:Nh) = Amax*((1:Ah)./Ah).^Am;  % right part PML E
App = 1+A;          % puls PML E vector
Amm = 1-A;          % minus PML E vector
AH = (A(2:Nh) + A(1:Nh-1))/2; % PML H i+1/2
AH = [AH; AH(end)]; % PML H i+1/2 complete vector
AHpp = 1+AH;        % puls PML H vector
AHmm = 1-AH;        % minus PML H vector
z = linspace(0,h*Nh,Nh); % position of E, mum
E = zeros(Nh,1);    % electric field, ab.unit.
H = zeros(Nh,1);    % magnetic field, 
z0 = z(Mst);        % medium surface
ep = ones(Nh,1);    % permittivity vector
ep(Mst:Nh) = eps00; % setup permittivity vector from eps00
eee = e0./(ep*eps0);% response parameter
Ms = Nh-Mst+1;      % medium size
D = D.*ones(Ms,1);  % diffusion constant, mum^2/ps
g = g.*ones(Ms,1);  % electron scattering rate, ps^-1
al = (4-2*w0^2*dt^2)./(2 + g*dt);       % alpha parameter
be = (g*dt-2)./(g.*dt+2);               % beta parameter
th = 2.*e0.*dt.^2./ meff./(2 + g.*dt);  % theta parameter
x0 = zeros(Ms,1);   % temporary displacement vector
x = zeros(Ms,1);    % current displacement vector
zz = transpose(z(Mst:Nh)-z0);           % reduced position vector
N =  Nmax*exp(-zz/abp);                 % Nmax*ones(Ms,1)

for n = 1:Nt        % time step   
% Source
    S = EA.*sin(ome0*(n*dt-t0)).*exp(-(n*dt-t0).^2/(2*pulseW^2));
    E(Ah+5) = E(Ah+5) + S;              % adding current source 
    H(Ah+5) = H(Ah+5) + Q*S;            % unidirectional propagation
    N0 =  N;        % store old density
    N(2:Ms-1) = N(2:Ms-1).*(1 - dt.*rb - 2.*dt./(h.^2).*D(2:Ms-1))... 
        + dt.*D(2:Ms-1)./(h.^2) .* ( N(3:Ms) + N(1:Ms-2) );%... 
    N(Ms) = N0(Ms).*(1 - dt.*rb - dt./(h.^2).*D(Ms))...
        + dt.*D(Ms)./(h.^2) .* ( N0(Ms-1) ); 
    N(1) = N0(1).*(1-dt*rs/h - dt.*rb - dt./(h.^2).*D(1))...
        + dt.*D(1)./(h.^2) .* N0(2);
% Evolve x fields, displacement
    x1 = x0;        % older displacement
    x0 = x;         % old dispacement
    x = al.*x0 + be.*x1 - th.*E(Mst:Nh);
    J(Mst:Nh) = N.*(x - x0).*eee(Mst:Nh);
% Evolve E field
    E(1) = 1./App(1).*(Amm(1).*E(1) - Q./ep(1).*H(1));
    E(2:Nh) = 1./App(2:Nh).*( Amm(2:Nh).*E(2:Nh)...
        - Q./ep(2:Nh).*(H(2:Nh) - H(1:Nh-1)) ) + J(2:Nh).';
% Evolve H field
    H(1:Nh-1) = 1./AHpp(1:Nh-1).*( AHmm(1:Nh-1).*H(1:Nh-1)...
        - Q.*( E(2:Nh) - E(1:Nh-1) ) );
    H(Nh) = 1./AHpp(Nh).*( AHmm(Nh).*H(Nh) + Q.*E(Nh) );
% Plot 'realtime'
    if ~mod(n,1)
        cla         % clear figure
        line(z,E/EA*2) % plot E
        line(zz+z0,N/Nmax) % plot N
        ylim([-0.5,1.1])
        drawnow  
    end
end
