%% FDTD-TRTS
% FDTD implementation of time-resolved THz-spectroscopy (TRTS)
% Developed by Casper Larsen, 2010, DTU, Denmark
% Please cite: "C. Larsen, D. Cooke, P. U. Jepsen, Finite-Difference
% Time-Domain Analysis of Time-resolved THz Spectroscopy Experiments, JOSA B 2011".
% See user manual for explanations and usage

%% plot data from the simulation
zlims1 = [0.4 1.2];
zlims2 = [-0.3 1];
load tut06.mat
ps.plot = 2;
clFDTplot(c,m,ps,o)
subplot(2,2,3)
zlim(zlims1)
xlim([-1.5 3.5])
subplot(2,2,4)
zlim(zlims2)
xlim([-1.5 3.5])
clear o

% plot experimental data
figcon = figure;
nlines = 20;
nskip =1;
viewposT = [31.5 34];
ylabelrot = -45;
                
o = struct;
tmp = importdata('GaAs800.pmp');
o.t2 = tmp(2:end,1);
o.vtp = tmp(1,2:end)-1.5;
o.CdetT2Dfix = fliplr(tmp(2:end,2:end));

tmp = importdata('GaAs800.ref');
o.CdetT2Dref = fliplr(tmp(2:end,2:end)); 
o.CDdetT2Dfix = o.CdetT2Dfix - o.CdetT2Dref;

[o.f,o.CEwr,o.absCEwr,o.phaCEwr] = clfft(o.t2,o.CdetT2Dref,'tf',ps.Nfft); % Epumpcon(w,tp)
[o.f,o.CEwp,o.absCEwp,o.phaCEwp] = clfft(o.t2,o.CdetT2Dfix,'tf',ps.Nfft); % Epumpcon(w,tp)
o.CT = o.absCEwp ./ o.absCEwr; % transmission, con
o.CPhi = unwrap(o.phaCEwp - o.phaCEwr,[],2); % phase and unwrap across tp, con

o.nnumin = find(o.f >= ps.fxlim(1),1,'first');
o.nnumax = find(o.f >= ps.fxlim(2),1,'first');
o.vecnu = o.nnumin:o.nnumax;
o.fnu = o.f(o.vecnu);

o.CPhi = o.CPhi-round(mean(mean(o.CPhi(o.vecnu,:)))/(2*pi))*2*pi;

colormap(gray(8))
subplot(222)
hold all, grid on 
contour(o.t2,o.vtp,-o.CDdetT2Dfix.',nlines);
xlim([min(o.t2) max(o.t2)])
xlabel('THz delay t, ps')
ylabel('Pump-sampling delay t_p, ps')
set(gca,'DataAspectRatio',[1 1 1],...
    'DataAspectRatioMode','manual')
title('-\Delta E(t,t_{p})')
colorbar('location','East')

a1 = subplot(2,2,3,'Parent',figcon);
hold all, grid on 
surf(o.vtp(1:nskip:end),o.fnu(1:nskip:end),o.CT(o.vecnu(1:nskip:end),1:nskip:end),...
    'Parent',a1,'FaceColor',[1 1 1]),
view(viewposT);
zlabel('T(\omega)')
ylabel('Frequency, THz','Rotation',-ylabelrot)
xlabel('t_p, ps')
xlim([min(o.vtp) max(o.vtp)])
ylim([min(o.fnu) max(o.fnu)])
zlim(zlims1)

a2 = subplot(2,2,4,'Parent',figcon);
hold all, grid on 
surf(o.vtp(1:nskip:end),o.fnu(1:nskip:end),-o.CPhi(o.vecnu(1:nskip:end),1:nskip:end),...
    'Parent',a2,'FaceColor',[1 1 1]),
view(viewposT);
zlabel('-\Phi(\omega)')
ylabel('Frequency, THz','Rotation',-ylabelrot)
xlabel('t_p, ps')
xlim([min(o.vtp) max(o.vtp)])
ylim([min(o.fnu) max(o.fnu)])
zlim(zlims2)